import UIKit

class Araba {
    var renk:String?
    var hiz:Int?
    var calisiyorMu:Bool?
   
    init(){
        print ("Boş init metodu çalıştı")
    }
   // init (renkx:String,hizx:Int, calisiyorMux:Bool){
     //   renkx = renk
    // hizx = hiz
     //   calisiyorMux = calisiyorMu
    //bu yapı her ne kadar doğru olsa bile biz daha düzgün bir gösterim için kullanmayız. Bunun yerine aşağıda self. şeklinde kullanırız
   // }
    
    
    init (renk:String,hiz:Int, calisiyorMu:Bool){
        self.renk = renk
        self.hiz = hiz
        self.calisiyorMu = calisiyorMu
        print ("Dolu init metodu çalıştı")
    }
    func calistir(){
        calisiyorMu = true
        hiz = 5
    }
    func durdur(){
        calisiyorMu = false
        hiz = 0
    }
    
    func hizlan(kaçKm:Int){
        hiz!+=kaçKm
    }
    
    func yavasla(kaçKm:Int){
        hiz!-=kaçKm
    }
    func bilgiAl() {
        print (".................................")
        print ("Renk         :\(renk!)")
        print ("Hız          :\(hiz!)")
        print ("Çalışıyor mu :\(calisiyorMu!)")
        
    }
}

//Nesne oluşturma
//var bmw = Araba ()

//Değer atama
//bmw.renk = "Kırmızı"
//bmw.hiz = 100
//bmw.calisiyorMu = true dolu initle yapmak istersek bunu sadece aşağıda olan bir satır ile yapabiliriz.
var bmw = Araba(renk: "kırmızı", hiz: 100, calisiyorMu: true)
//Değer Okuma
//print (".................................")
//print ("Renk         :\(bmw.renk!)")
//print ("Hız          :\(bmw.hiz!)")
//print ("Çalışıyor mu :\(bmw.calisiyorMu!)") bu kadar uzun yazmak yerine aşağıda olan tek satırı yazarız.

bmw.bilgiAl()
bmw.durdur()
bmw.bilgiAl()
bmw.calistir()
bmw.bilgiAl()
bmw.hizlan(kaçKm: 50)
bmw.bilgiAl()
bmw.yavasla(kaçKm: 10)
bmw.bilgiAl()


var sahin = Araba ()

sahin.renk = "Beyaz"
sahin.hiz = 0
sahin.calisiyorMu = false

//print (".................................")
//print ("Renk         :\(sahin.renk!)")
//print ("Hız          :\(sahin.hiz!)")
//print ("Çalışıyor mu :\(sahin.calisiyorMu!)") değer okumayı bu kadar uzun yazmak yerine sadece aşağıdaki tek satırı yazarız.

 sahin.bilgiAl()
sahin.calistir()
sahin.bilgiAl()
sahin.durdur()
sahin.bilgiAl()
sahin.calistir()
sahin.bilgiAl()
sahin.hizlan(kaçKm: 150)
sahin.bilgiAl()
sahin.yavasla(kaçKm: 25)
sahin.bilgiAl()



